package com.example.rvtask.model

data class UsersData (
     var name:String,
     var phone:String,
     var description:String,
     var image_link:String

)


